import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Music, Search, User, LogOut } from "lucide-react";
import "../theme/theme.css";

interface NavbarProps {
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onLogout }) => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <nav
      style={{
        position: "sticky",
        top: 0,
        zIndex: 100,
        padding: "1rem 2rem",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        background: "var(--gradient-coffee)",
        color: "var(--text-inverse)",
        backdropFilter: "blur(10px)",
        borderBottom: "1px solid var(--border-dark)",
        boxShadow: "var(--shadow-lg)"
      }}
    >
      {/* Logo/Brand */}
      <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
        <Music size={24} />
        <h1 style={{ margin: 0, fontSize: "1.5rem", fontWeight: "bold" }}>
          Rhythmic Tunes
        </h1>
      </div>

      {/* Navigation Links */}
      <div style={{ display: "flex", gap: "2rem" }}>
        <button
          onClick={() => navigate("/")}
          style={{
            color: "inherit",
            background: "none",
            border: "none",
            padding: "0.5rem 1rem",
            borderRadius: "4px",
            transition: "background-color 0.2s",
            cursor: "pointer",
          }}
          onMouseEnter={(e) =>
            (e.currentTarget.style.backgroundColor =
              "var(--coffee-secondary)")
          }
          onMouseLeave={(e) =>
            (e.currentTarget.style.backgroundColor = "transparent")
          }
        >
          Home
        </button>
        <button
          onClick={() => navigate("/library")}
          style={{
            color: "inherit",
            background: "none",
            border: "none",
            padding: "0.5rem 1rem",
            borderRadius: "4px",
            transition: "background-color 0.2s",
            cursor: "pointer",
          }}
          onMouseEnter={(e) =>
            (e.currentTarget.style.backgroundColor =
              "var(--coffee-secondary)")
          }
          onMouseLeave={(e) =>
            (e.currentTarget.style.backgroundColor = "transparent")
          }
        >
          Library
        </button>
        <button
          style={{
            color: "inherit",
            background: "none",
            border: "none",
            padding: "0.5rem 1rem",
            borderRadius: "4px",
            transition: "background-color 0.2s",
            cursor: "pointer",
          }}
          onMouseEnter={(e) =>
            (e.currentTarget.style.backgroundColor =
              "var(--coffee-secondary)")
          }
          onMouseLeave={(e) =>
            (e.currentTarget.style.backgroundColor = "transparent")
          }
        >
          Playlists
        </button>
      </div>

      {/* Search & User Actions */}
      <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
        <div style={{
          position: "relative",
          display: "flex",
          alignItems: "center",
          background: "var(--gradient-warm)",
          borderRadius: "25px",
          padding: "0.5rem 1rem",
          boxShadow: "var(--shadow-sm)",
          border: "1px solid var(--border-light)"
        }}>
          <Search size={18} style={{ color: "var(--coffee-primary)", marginRight: "0.5rem" }} />
          <input
            type="search"
            placeholder="Search music..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{
              background: "transparent",
              border: "none",
              outline: "none",
              color: "var(--text-primary)",
              width: "200px",
              fontSize: "0.9rem"
            }}
          />
        </div>
        <img
          onClick={() => navigate("/profile")}
          src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face"
          alt="User Profile"
          style={{
            width: "40px",
            height: "40px",
            borderRadius: "50%",
            objectFit: "cover",
            cursor: "pointer",
            border: "2px solid var(--text-inverse)",
            transition: "transform 0.2s"
          }}
          onMouseEnter={(e) => e.currentTarget.style.transform = "scale(1.1)"}
          onMouseLeave={(e) => e.currentTarget.style.transform = "scale(1)"}
        />
        <button
          onClick={onLogout}
          style={{
            color: "inherit",
            background: "none",
            border: "1px solid var(--text-inverse)",
            padding: "0.5rem",
            borderRadius: "50%",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            transition: "background-color 0.2s",
          }}
          onMouseEnter={(e) =>
            (e.currentTarget.style.backgroundColor = "var(--coffee-secondary)")
          }
          onMouseLeave={(e) =>
            (e.currentTarget.style.backgroundColor = "transparent")
          }
          title="Logout"
        >
          <LogOut size={18} />
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
