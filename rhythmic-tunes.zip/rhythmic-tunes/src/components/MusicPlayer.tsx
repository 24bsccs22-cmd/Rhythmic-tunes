import React from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, Heart, Repeat } from 'lucide-react';
import { useMusicPlayer } from '../context/MusicPlayerContext.tsx';

const MusicPlayer: React.FC = () => {
  const {
    currentSong,
    isPlaying,
    volume,
    currentTime,
    duration,
    isLooping,
    isFavorite,
    togglePlay,
    nextSong,
    previousSong,
    setVolume,
    toggleLoop,
    toggleFavorite,
    seekTo,
  } = useMusicPlayer();

  // Always show the player, even when no song is selected

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const width = rect.width;
    const newTime = (clickX / width) * duration;
    seekTo(newTime);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
  };

  return (
    <div style={{
      position: 'fixed',
      bottom: 0,
      left: 0,
      right: 0,
      height: '90px',
      backgroundColor: 'var(--card-background)',
      borderTop: '1px solid var(--border-light)',
      display: 'flex',
      alignItems: 'center',
      padding: '0 1rem',
      boxShadow: '0 -4px 12px rgba(0,0,0,0.1)',
      zIndex: 1000,
    }}>
      {/* Song Info */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        minWidth: '300px',
        flex: '0 0 300px',
      }}>
        {currentSong ? (
          <>
            <img
              src={currentSong.image}
              alt={currentSong.title}
              style={{
                width: '60px',
                height: '60px',
                borderRadius: '8px',
                objectFit: 'cover',
                marginRight: '1rem',
              }}
            />
            <div style={{ minWidth: 0 }}>
              <div style={{
                fontWeight: '600',
                color: 'var(--text-primary)',
                fontSize: '0.9rem',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                marginBottom: '0.25rem',
              }}>
                {currentSong.title}
              </div>
              <div style={{
                fontSize: '0.8rem',
                color: 'var(--text-secondary)',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
              }}>
                {currentSong.artist}
              </div>
            </div>
            <button
              onClick={toggleFavorite}
              style={{
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                padding: '0.5rem',
                marginLeft: '1rem',
                color: isFavorite ? '#e74c3c' : 'var(--text-muted)',
                transition: 'color 0.2s',
              }}
            >
              <Heart size={20} fill={isFavorite ? '#e74c3c' : 'none'} />
            </button>
          </>
        ) : (
          <div style={{
            display: 'flex',
            alignItems: 'center',
          }}>
            <div style={{
              width: '60px',
              height: '60px',
              borderRadius: '8px',
              backgroundColor: 'var(--cream-secondary)',
              marginRight: '1rem',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
              <Play size={24} style={{ color: 'var(--text-muted)' }} />
            </div>
            <div>
              <div style={{
                fontWeight: '600',
                color: 'var(--text-muted)',
                fontSize: '0.9rem',
                marginBottom: '0.25rem',
              }}>
                No song selected
              </div>
              <div style={{
                fontSize: '0.8rem',
                color: 'var(--text-muted)',
              }}>
                Choose a song to play
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Player Controls */}
      <div style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        maxWidth: '600px',
        margin: '0 2rem',
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '1rem',
          marginBottom: '0.5rem',
        }}>
          <button
            onClick={currentSong ? toggleLoop : undefined}
            disabled={!currentSong}
            style={{
              background: 'none',
              border: 'none',
              cursor: currentSong ? 'pointer' : 'not-allowed',
              padding: '0.5rem',
              color: currentSong && isLooping ? 'var(--coffee-primary)' : 'var(--text-muted)',
              transition: 'color 0.2s',
              opacity: currentSong ? 1 : 0.5,
            }}
          >
            <Repeat size={18} />
          </button>
          <button
            onClick={currentSong ? previousSong : undefined}
            disabled={!currentSong}
            style={{
              background: 'none',
              border: 'none',
              cursor: currentSong ? 'pointer' : 'not-allowed',
              padding: '0.5rem',
              color: 'var(--text-primary)',
              opacity: currentSong ? 1 : 0.5,
            }}
          >
            <SkipBack size={20} />
          </button>
          <button
            onClick={currentSong ? togglePlay : undefined}
            disabled={!currentSong}
            style={{
              background: currentSong ? 'var(--coffee-primary)' : 'var(--text-muted)',
              border: 'none',
              borderRadius: '50%',
              width: '40px',
              height: '40px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: currentSong ? 'pointer' : 'not-allowed',
              color: 'white',
              transition: 'transform 0.2s',
              opacity: currentSong ? 1 : 0.5,
            }}
            onMouseEnter={(e) => currentSong && (e.currentTarget.style.transform = 'scale(1.05)')}
            onMouseLeave={(e) => currentSong && (e.currentTarget.style.transform = 'scale(1)')}
          >
            {currentSong && isPlaying ? <Pause size={18} /> : <Play size={18} />}
          </button>
          <button
            onClick={currentSong ? nextSong : undefined}
            disabled={!currentSong}
            style={{
              background: 'none',
              border: 'none',
              cursor: currentSong ? 'pointer' : 'not-allowed',
              padding: '0.5rem',
              color: 'var(--text-primary)',
              opacity: currentSong ? 1 : 0.5,
            }}
          >
            <SkipForward size={20} />
          </button>
        </div>

        {/* Progress Bar */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          width: '100%',
          gap: '0.75rem',
        }}>
          <span style={{
            fontSize: '0.75rem',
            color: 'var(--text-muted)',
            minWidth: '35px',
          }}>
            {formatTime(currentTime)}
          </span>
          <div
            onClick={handleProgressClick}
            style={{
              flex: 1,
              height: '4px',
              backgroundColor: 'var(--cream-secondary)',
              borderRadius: '2px',
              cursor: 'pointer',
              position: 'relative',
            }}
          >
            <div style={{
              width: `${duration ? (currentTime / duration) * 100 : 0}%`,
              height: '100%',
              backgroundColor: 'var(--coffee-primary)',
              borderRadius: '2px',
              transition: 'width 0.1s',
            }} />
          </div>
          <span style={{
            fontSize: '0.75rem',
            color: 'var(--text-muted)',
            minWidth: '35px',
          }}>
            {formatTime(duration)}
          </span>
        </div>
      </div>

      {/* Volume Control */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        minWidth: '150px',
        flex: '0 0 150px',
        justifyContent: 'flex-end',
      }}>
        <Volume2 size={18} style={{ color: 'var(--text-muted)', marginRight: '0.5rem' }} />
        <input
          type="range"
          min="0"
          max="1"
          step="0.01"
          value={volume}
          onChange={handleVolumeChange}
          style={{
            width: '80px',
            height: '4px',
            background: `linear-gradient(to right, var(--coffee-primary) 0%, var(--coffee-primary) ${volume * 100}%, var(--cream-secondary) ${volume * 100}%, var(--cream-secondary) 100%)`,
            borderRadius: '2px',
            outline: 'none',
            cursor: 'pointer',
            WebkitAppearance: 'none',
          }}
        />
      </div>
    </div>
  );
};

export default MusicPlayer;