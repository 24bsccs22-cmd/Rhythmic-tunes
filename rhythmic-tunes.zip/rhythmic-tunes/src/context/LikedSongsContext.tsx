import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface Song {
  id: string;
  title: string;
  artist: string;
  image: string;
}

interface LikedSongsContextType {
  likedSongs: Song[];
  addToLiked: (song: Song) => void;
  removeFromLiked: (songId: string) => void;
  isLiked: (songId: string) => boolean;
}

const LikedSongsContext = createContext<LikedSongsContextType | undefined>(undefined);

export const LikedSongsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [likedSongs, setLikedSongs] = useState<Song[]>([]);

  const addToLiked = (song: Song) => {
    setLikedSongs(prev => [...prev, song]);
  };

  const removeFromLiked = (songId: string) => {
    setLikedSongs(prev => prev.filter(song => song.id !== songId));
  };

  const isLiked = (songId: string) => {
    return likedSongs.some(song => song.id === songId);
  };

  return (
    <LikedSongsContext.Provider value={{ likedSongs, addToLiked, removeFromLiked, isLiked }}>
      {children}
    </LikedSongsContext.Provider>
  );
};

export const useLikedSongs = () => {
  const context = useContext(LikedSongsContext);
  if (!context) {
    throw new Error('useLikedSongs must be used within a LikedSongsProvider');
  }
  return context;
};