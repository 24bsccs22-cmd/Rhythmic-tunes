import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { useState, useEffect } from "react";
import Navbar from "./components/Navbar.tsx";
import Home from "./pages/Home.tsx";
import Library from "./pages/Library.tsx";
import MusicPlayer from "./components/MusicPlayer.tsx";
import { MusicPlayerProvider } from "./context/MusicPlayerContext.tsx";
import { LikedSongsProvider } from "./context/LikedSongsContext.tsx";
import "./theme/theme.css";
import Profile from "./pages/Profile.tsx";
import Login from "./pages/Login.tsx";
import Register from "./pages/Register.tsx";
import OTP from "./pages/OTP.tsx";
import LikedSongs from "./pages/LikedSongs.tsx";
import RecentlyPlayed from "./pages/RecentlyPlayed.tsx";
import DailyMix from "./pages/DailyMix.tsx";
import DiscoverWeekly from "./pages/DiscoverWeekly.tsx";
import TopArtist from "./pages/TopArtist.tsx";
import TopSongs from "./pages/TopSongs.tsx";
import AllSongs from "./pages/AllSongs.tsx";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const loginStatus = localStorage.getItem("isLoggedIn");
    const currentUser = localStorage.getItem("currentUser");
    setIsLoggedIn(loginStatus === "true" && currentUser !== null);
  }, []);

  const handleLogin = () => {
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("currentUser");
    setIsLoggedIn(false);
  };

  return (
    <LikedSongsProvider>
      <MusicPlayerProvider>
        <Router>
          {!isLoggedIn ? (
            <Routes>
              <Route path="/register" element={<Register />} />
              <Route path="/otp" element={<OTP />} />
              <Route path="/" element={<Login onLogin={handleLogin} />} />
            </Routes>
          ) : (
            <div className="App" style={{ paddingBottom: "90px" }}>
              <Navbar onLogout={handleLogout} />
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/library" element={<Library />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/liked-songs" element={<LikedSongs />} />
                <Route path="/recently-played" element={<RecentlyPlayed />} />
                <Route path="/daily-mix" element={<DailyMix />} />
                <Route path="/discover-weekly" element={<DiscoverWeekly />} />
                <Route path="/top-artist" element={<TopArtist />} />
                <Route path="/top-songs" element={<TopSongs />} />
                <Route path="/all-songs" element={<AllSongs />} />
              </Routes>
              <MusicPlayer />
            </div>
          )}
        </Router>
      </MusicPlayerProvider>
    </LikedSongsProvider>
  );
}

export default App;
