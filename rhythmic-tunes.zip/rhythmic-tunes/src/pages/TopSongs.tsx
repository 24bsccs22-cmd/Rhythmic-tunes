import React from "react";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

const TopSongs: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div style={{ minHeight: "100vh", background: "var(--gradient-warm)", padding: "2rem 3rem" }}>
      <button
        onClick={() => navigate("/")}
        style={{
          display: "flex",
          alignItems: "center",
          gap: "0.5rem",
          background: "none",
          border: "none",
          color: "var(--text-primary)",
          fontSize: "1rem",
          cursor: "pointer",
          marginBottom: "2rem"
        }}
      >
        <ArrowLeft size={20} />
        Back to Home
      </button>
      
      <h1 style={{ fontSize: "3rem", fontWeight: "900", color: "var(--text-primary)", marginBottom: "1rem" }}>
        Your Top Songs 2024
      </h1>
      <p style={{ color: "var(--text-secondary)", fontSize: "1.1rem" }}>
        Your most played songs this year
      </p>
    </div>
  );
};

export default TopSongs;