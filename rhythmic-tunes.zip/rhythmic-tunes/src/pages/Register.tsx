import React, { useState, FormEvent } from "react";
import { UserPlus, Music, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import "../theme/theme.css";

const Register: React.FC = () => {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (username && email && password && confirmPassword) {
      if (password !== confirmPassword) {
        alert("Passwords don't match!");
        return;
      }
      
      setIsLoading(true);
      
      // Check if user already exists
      const existingUsers = JSON.parse(localStorage.getItem("users") || "[]");
      const userExists = existingUsers.find((user: any) => user.email === email);
      
      if (userExists) {
        setIsLoading(false);
        alert("User already exists with this email!");
        return;
      }
      
      // Store new user
      const newUser = { username, email, password };
      existingUsers.push(newUser);
      localStorage.setItem("users", JSON.stringify(existingUsers));
      
      setTimeout(() => {
        setIsLoading(false);
        alert("Account created successfully! Please verify your email.");
        navigate("/otp", { state: { email } });
      }, 1000);
    }
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "var(--gradient-warm)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "2rem 1rem",
      }}
    >
      <div
        style={{
          background: "var(--card-background)",
          borderRadius: "16px",
          padding: "3rem",
          boxShadow: "var(--shadow-lg)",
          border: "1px solid var(--border-light)",
          width: "100%",
          maxWidth: "400px",
        }}
      >
        <div
          style={{
            textAlign: "center",
            marginBottom: "2rem",
          }}
        >
          <div
            style={{
              background: "var(--gradient-coffee)",
              borderRadius: "50%",
              width: "80px",
              height: "80px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 auto 1rem auto",
            }}
          >
            <Music size={40} color="white" />
          </div>
          <h1
            style={{
              fontSize: "2rem",
              fontWeight: "700",
              color: "var(--text-primary)",
              margin: "0 0 0.5rem 0",
            }}
          >
            Create Account
          </h1>
          <p
            style={{
              color: "var(--text-secondary)",
              fontSize: "1rem",
              margin: 0,
            }}
          >
            Join Rhythmic Tunes and start your musical journey
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: "1.5rem" }}>
            <label
              style={{
                display: "block",
                fontWeight: "500",
                color: "var(--text-primary)",
                marginBottom: "0.5rem",
                fontSize: "0.9rem",
              }}
            >
              Username
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              style={{
                width: "calc(100% - 0.2rem)",
                padding: "0.75rem",
                border: "2px solid var(--input-border)",
                borderRadius: "8px",
                background: "var(--input-background)",
                color: "var(--text-primary)",
                fontSize: "1rem",
                outline: "none",
                transition: "border-color 0.2s",
              }}
              placeholder="Enter your username"
            />
          </div>

          <div style={{ marginBottom: "1.5rem" }}>
            <label
              style={{
                display: "block",
                fontWeight: "500",
                color: "var(--text-primary)",
                marginBottom: "0.5rem",
                fontSize: "0.9rem",
              }}
            >
              Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              style={{
                width: "calc(100% - 0.2rem)",
                padding: "0.75rem",
                border: "2px solid var(--input-border)",
                borderRadius: "8px",
                background: "var(--input-background)",
                color: "var(--text-primary)",
                fontSize: "1rem",
                outline: "none",
                transition: "border-color 0.2s",
              }}
              placeholder="Enter your email"
            />
          </div>

          <div style={{ marginBottom: "1.5rem" }}>
            <label
              style={{
                display: "block",
                fontWeight: "500",
                color: "var(--text-primary)",
                marginBottom: "0.5rem",
                fontSize: "0.9rem",
              }}
            >
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={{
                width: "calc(100% - 0.2rem)",
                padding: "0.75rem",
                border: "2px solid var(--input-border)",
                borderRadius: "8px",
                background: "var(--input-background)",
                color: "var(--text-primary)",
                fontSize: "1rem",
                outline: "none",
                transition: "border-color 0.2s",
              }}
              placeholder="Enter your password"
            />
          </div>

          <div style={{ marginBottom: "2rem" }}>
            <label
              style={{
                display: "block",
                fontWeight: "500",
                color: "var(--text-primary)",
                marginBottom: "0.5rem",
                fontSize: "0.9rem",
              }}
            >
              Confirm Password
            </label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
              style={{
                width: "calc(100% - 0.2rem)",
                padding: "0.75rem",
                border: "2px solid var(--input-border)",
                borderRadius: "8px",
                background: "var(--input-background)",
                color: "var(--text-primary)",
                fontSize: "1rem",
                outline: "none",
                transition: "border-color 0.2s",
              }}
              placeholder="Confirm your password"
            />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            style={{
              width: "100%",
              padding: "0.875rem",
              background: isLoading ? "var(--text-secondary)" : "var(--gradient-hero)",
              color: "white",
              border: "none",
              borderRadius: "8px",
              fontSize: "1rem",
              fontWeight: "600",
              cursor: isLoading ? "not-allowed" : "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "0.5rem",
              transition: "transform 0.2s",
            }}
          >
            {isLoading ? (
              <>
                <Loader2 size={20} className="animate-spin" style={{ animation: "spin 1s linear infinite" }} />
                Creating Account...
              </>
            ) : (
              <>
                <UserPlus size={20} />
                Create Account
              </>
            )}
          </button>
        </form>

        <div
          style={{
            marginTop: "2rem",
            textAlign: "center",
          }}
        >
          <p
            style={{
              fontSize: "0.9rem",
              color: "var(--text-secondary)",
              margin: 0,
            }}
          >
            Already have an account?{" "}
            <button
              onClick={() => navigate("/login")}
              style={{
                background: "none",
                border: "none",
                color: "var(--gradient-hero)",
                cursor: "pointer",
                textDecoration: "underline",
                fontSize: "0.9rem",
                fontWeight: "600",
              }}
            >
              Login now!
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Register;