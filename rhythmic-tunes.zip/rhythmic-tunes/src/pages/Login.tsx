import React, { useState, FormEvent } from "react";
import { LogIn, Music, Eye, EyeOff } from "lucide-react";
import { useNavigate } from "react-router-dom";
import "../theme/theme.css";

interface LoginProps {
  onLogin: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setError("");
    
    if (!email || !password) {
      setError("Please fill in all fields");
      return;
    }
    
    // Check if user exists
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    const user = users.find((u: any) => u.email === email && u.password === password);
    
    if (user) {
      localStorage.setItem("isLoggedIn", "true");
      localStorage.setItem("currentUser", JSON.stringify(user));
      onLogin();
    } else {
      setError("User not found. Please register first or check your credentials.");
    }
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "var(--gradient-warm)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "2rem 1rem",
      }}
    >
      <div
        style={{
          background: "var(--card-background)",
          borderRadius: "16px",
          padding: "3rem",
          boxShadow: "var(--shadow-lg)",
          border: "1px solid var(--border-light)",
          width: "100%",
          maxWidth: "400px",
        }}
      >
        <div
          style={{
            textAlign: "center",
            marginBottom: "2rem",
          }}
        >
          <div
            style={{
              background: "var(--gradient-coffee)",
              borderRadius: "50%",
              width: "80px",
              height: "80px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 auto 1rem auto",
            }}
          >
            <Music size={40} color="white" />
          </div>
          <h1
            style={{
              fontSize: "2rem",
              fontWeight: "700",
              color: "var(--text-primary)",
              margin: "0 0 0.5rem 0",
            }}
          >
            Welcome Back
          </h1>
          <p
            style={{
              color: "var(--text-secondary)",
              fontSize: "1rem",
              margin: 0,
            }}
          >
            Sign in to your Rhythmic Tunes account
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: "1.5rem" }}>
            <label
              style={{
                display: "block",
                fontWeight: "500",
                color: "var(--text-primary)",
                marginBottom: "0.5rem",
                fontSize: "0.9rem",
              }}
            >
              Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              style={{
                width: "calc(100% - 0.2rem)",
                padding: "0.75rem",
                border: "2px solid var(--input-border)",
                borderRadius: "8px",
                background: "var(--input-background)",
                color: "var(--text-primary)",
                fontSize: "1rem",
                outline: "none",
                transition: "border-color 0.2s",
              }}
              placeholder="Enter your email"
            />
          </div>

          <div style={{ marginBottom: "2rem" }}>
            <label
              style={{
                display: "block",
                fontWeight: "500",
                color: "var(--text-primary)",
                marginBottom: "0.5rem",
                fontSize: "0.9rem",
              }}
            >
              Password
            </label>
            <div style={{ position: "relative" }}>
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                style={{
                  width: "calc(100% - 0.2rem)",
                  padding: "0.75rem 3rem 0.75rem 0.75rem",
                  border: "2px solid var(--input-border)",
                  borderRadius: "8px",
                  background: "var(--input-background)",
                  color: "var(--text-primary)",
                  fontSize: "1rem",
                  outline: "none",
                  transition: "border-color 0.2s",
                }}
                placeholder="Enter your password"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                style={{
                  position: "absolute",
                  right: "0.90rem",
                  top: "50%",
                  transform: "translateY(-50%)",
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  color: "var(--text-secondary)",
                  padding: "0.35rem",
                }}
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          {error && (
            <div
              style={{
                marginBottom: "1rem",
                padding: "0.75rem",
                background: "#fee2e2",
                border: "1px solid #fecaca",
                borderRadius: "8px",
                color: "#dc2626",
                fontSize: "0.9rem",
                textAlign: "center",
              }}
            >
              {error}
            </div>
          )}

          <button
            type="submit"
            style={{
              width: "100%",
              padding: "0.875rem",
              background: "var(--gradient-hero)",
              color: "white",
              border: "none",
              borderRadius: "8px",
              fontSize: "1rem",
              fontWeight: "600",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "0.5rem",
              transition: "transform 0.2s",
            }}
          >
            <LogIn size={20} />
            Sign In
          </button>
        </form>

        <div
          style={{
            marginTop: "2rem",
            textAlign: "center",
          }}
        >
          <p
            style={{
              fontSize: "0.9rem",
              color: "var(--text-secondary)",
              margin: "0 0 1rem 0",
            }}
          >
            Don't have an account?{" "}
            <button
              onClick={() => navigate("/register")}
              style={{
                background: "none",
                border: "none",
                color: "var(--gradient-hero)",
                cursor: "pointer",
                textDecoration: "underline",
                fontSize: "0.9rem",
                fontWeight: "600",
              }}
            >
              Create Account
            </button>
          </p>
        </div>

        <div
          style={{
            padding: "1rem",
            background: "var(--cream-secondary)",
            borderRadius: "8px",
            textAlign: "center",
          }}
        >
          <p
            style={{
              fontSize: "0.85rem",
              color: "var(--text-secondary)",
              margin: 0,
            }}
          >
            Please register first to create an account
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
