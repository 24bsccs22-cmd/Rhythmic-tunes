import React, { useState, useEffect, ChangeEvent } from "react";
import { Camera, LogOut, Save, Edit3 } from "lucide-react";
import "../theme/theme.css";

interface ProfileData {
  name: string;
  bio: string;
  email: string;
  image: string;
  joinDate: string;
}

const Profile: React.FC = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [profile, setProfile] = useState<ProfileData>({
    name: "John Doe",
    bio: "Music lover and coffee enthusiast",
    email: "john.doe@example.com",
    image:
      "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=face",
    joinDate: "January 2024",
  });

  useEffect(() => {
    const savedProfile = localStorage.getItem("userProfile");
    if (savedProfile) {
      setProfile(JSON.parse(savedProfile));
    }
  }, []);

  const handleSave = () => {
    localStorage.setItem("userProfile", JSON.stringify(profile));
    setIsEditing(false);
  };

  const handleImageChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e: ProgressEvent<FileReader>) => {
        setProfile({ ...profile, image: e.target?.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "var(--gradient-warm)",
      padding: "2rem 1rem"
    }}>
      {/* Header */}
      <div style={{
        maxWidth: "1200px",
        margin: "0 auto",
        marginBottom: "2rem"
      }}>
        <h1 style={{
          fontSize: "2.5rem",
          fontWeight: "700",
          color: "var(--text-primary)",
          margin: "0 0 0.5rem 0"
        }}>Profile Settings</h1>
        <p style={{
          color: "var(--text-secondary)",
          fontSize: "1.1rem",
          margin: 0
        }}>Manage your account information and preferences</p>
      </div>

      <div style={{
        maxWidth: "1200px",
        margin: "0 auto",
        display: "grid",
        gridTemplateColumns: "1fr 2fr",
        gap: "2rem",
        alignItems: "start"
      }}>
        {/* Profile Card */}
        <div style={{
          background: "var(--card-background)",
          borderRadius: "12px",
          padding: "2rem",
          boxShadow: "var(--shadow-lg)",
          border: "1px solid var(--border-light)",
          textAlign: "center"
        }}>
          <div style={{ position: "relative", display: "inline-block", marginBottom: "1.5rem" }}>
            <img
              src={profile.image}
              alt="Profile"
              style={{
                width: "120px",
                height: "120px",
                borderRadius: "50%",
                objectFit: "cover",
                border: "4px solid var(--border-light)"
              }}
            />
            <label style={{
              position: "absolute",
              bottom: "5px",
              right: "5px",
              background: "var(--coffee-primary)",
              borderRadius: "50%",
              width: "36px",
              height: "36px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              boxShadow: "var(--shadow-sm)",
              border: "2px solid var(--white)"
            }}>
              <Camera size={16} color="white" />
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                style={{ display: "none" }}
              />
            </label>
          </div>

          {isEditing ? (
            <input
              value={profile.name}
              onChange={(e) => setProfile({ ...profile, name: e.target.value })}
              style={{
                fontSize: "1.5rem",
                fontWeight: "600",
                textAlign: "center",
                border: "2px solid var(--input-border)",
                borderRadius: "8px",
                padding: "0.75rem",
                marginBottom: "1rem",
                width: "calc(100% - 1.5rem)",
                background: "var(--input-background)",
                color: "var(--text-primary)",
                outline: "none"
              }}
            />
          ) : (
            <h2 style={{
              fontSize: "1.5rem",
              fontWeight: "600",
              margin: "0 0 0.5rem 0",
              color: "var(--text-primary)"
            }}>
              {profile.name}
            </h2>
          )}

          {isEditing ? (
            <textarea
              value={profile.bio}
              onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
              placeholder="Tell us about yourself..."
              style={{
                width: "calc(100% - 1.5rem)",
                minHeight: "80px",
                border: "2px solid var(--input-border)",
                borderRadius: "8px",
                padding: "0.75rem",
                resize: "vertical",
                background: "var(--input-background)",
                color: "var(--text-primary)",
                outline: "none",
                fontFamily: "inherit",
                fontSize: "0.95rem"
              }}
            />
          ) : (
            <p style={{
              color: "var(--text-secondary)",
              fontSize: "0.95rem",
              margin: "0 0 1.5rem 0",
              lineHeight: "1.5"
            }}>
              {profile.bio}
            </p>
          )}

          <div style={{
            display: "flex",
            gap: "0.75rem",
            justifyContent: "center",
            flexWrap: "wrap"
          }}>
            {isEditing ? (
              <button
                onClick={handleSave}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "0.5rem",
                  background: "var(--gradient-coffee)",
                  color: "white",
                  border: "none",
                  padding: "0.75rem 1.25rem",
                  borderRadius: "8px",
                  cursor: "pointer",
                  fontWeight: "500",
                  fontSize: "0.9rem"
                }}
              >
                <Save size={16} />
                Save Changes
              </button>
            ) : (
              <button
                onClick={() => setIsEditing(true)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "0.5rem",
                  background: "var(--gradient-hero)",
                  color: "white",
                  border: "none",
                  padding: "0.75rem 1.25rem",
                  borderRadius: "8px",
                  cursor: "pointer",
                  fontWeight: "500",
                  fontSize: "0.9rem"
                }}
              >
                <Edit3 size={16} />
                Edit Profile
              </button>
            )}

            <button
              onClick={() => {
                localStorage.removeItem("userProfile");
                localStorage.removeItem("isLoggedIn");
                window.location.reload();
              }}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.5rem",
                background: "var(--error)",
                color: "white",
                border: "none",
                padding: "0.75rem 1.25rem",
                borderRadius: "8px",
                cursor: "pointer",
                fontWeight: "500",
                fontSize: "0.9rem"
              }}
            >
              <LogOut size={16} />
              Logout
            </button>
          </div>
        </div>

        {/* Account Information */}
        <div style={{
          background: "var(--card-background)",
          borderRadius: "12px",
          padding: "2rem",
          boxShadow: "var(--shadow-lg)",
          border: "1px solid var(--border-light)"
        }}>
          <h3 style={{
            fontSize: "1.25rem",
            fontWeight: "600",
            color: "var(--text-primary)",
            margin: "0 0 1.5rem 0",
            paddingBottom: "0.75rem",
            borderBottom: "1px solid var(--border-light)"
          }}>Account Information</h3>
          
          <div style={{
            display: "grid",
            gap: "1.5rem"
          }}>
            <div style={{
              display: "grid",
              gridTemplateColumns: "120px 1fr",
              alignItems: "center",
              padding: "1rem",
              background: "var(--cream-secondary)",
              borderRadius: "8px",
              border: "1px solid var(--border-light)"
            }}>
              <label style={{
                fontWeight: "500",
                color: "var(--text-secondary)",
                fontSize: "0.9rem"
              }}>Email Address</label>
              <span style={{
                color: "var(--text-primary)",
                fontSize: "0.95rem"
              }}>{profile.email}</span>
            </div>

            <div style={{
              display: "grid",
              gridTemplateColumns: "120px 1fr",
              alignItems: "center",
              padding: "1rem",
              background: "var(--cream-secondary)",
              borderRadius: "8px",
              border: "1px solid var(--border-light)"
            }}>
              <label style={{
                fontWeight: "500",
                color: "var(--text-secondary)",
                fontSize: "0.9rem"
              }}>Member Since</label>
              <span style={{
                color: "var(--text-primary)",
                fontSize: "0.95rem"
              }}>{profile.joinDate}</span>
            </div>

            <div style={{
              display: "grid",
              gridTemplateColumns: "120px 1fr",
              alignItems: "center",
              padding: "1rem",
              background: "var(--cream-secondary)",
              borderRadius: "8px",
              border: "1px solid var(--border-light)"
            }}>
              <label style={{
                fontWeight: "500",
                color: "var(--text-secondary)",
                fontSize: "0.9rem"
              }}>Account Status</label>
              <span style={{
                color: "var(--success)",
                fontSize: "0.95rem",
                fontWeight: "500"
              }}>Active</span>
            </div>
          </div>

          <div style={{
            marginTop: "2rem",
            padding: "1.5rem",
            background: "var(--beige-light)",
            borderRadius: "8px",
            border: "1px solid var(--orange-primary)"
          }}>
            <h4 style={{
              fontSize: "1rem",
              fontWeight: "600",
              color: "var(--coffee-primary)",
              margin: "0 0 0.5rem 0"
            }}>Security Notice</h4>
            <p style={{
              fontSize: "0.9rem",
              color: "var(--coffee-secondary)",
              margin: 0,
              lineHeight: "1.4"
            }}>Keep your account secure by using a strong password and enabling two-factor authentication.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
