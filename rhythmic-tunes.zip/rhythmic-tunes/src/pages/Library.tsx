import React, { useEffect, useState, useCallback } from "react";
import { Play, Pause, MoreVertical } from "lucide-react";
import { Song, useMusicPlayer } from "../context/MusicPlayerContext.tsx";
import "../theme/theme.css";

const songs: Song[] = [
  {
    id: 1,
    title: "Blinding Lights",
    artist: "The Weeknd",
    album: "After Hours",
    duration: "3:20",
    image: "/images/music-cover-list-1.png",
    audioUrl: "/audio/blinding-lights.mp3",
  },
  {
    id: 2,
    title: "Shape of You",
    artist: "Ed Sheeran",
    album: "÷ (Divide)",
    duration: "3:53",
    image: "/images/music-cover-list-2.png",
    audioUrl: "/audio/shapeofu.mp3",
  },
  {
    id: 3,
    title: "Bad Guy",
    artist: "Billie Eilish",
    album: "When We All Fall Asleep",
    duration: "3:14",
    image: "/images/music-cover-list-3.png",
    audioUrl: "/audio/badguy.mp3",
  },
  {
    id: 4,
    title: "Watermelon Sugar",
    artist: "Harry Styles",
    album: "Fine Line",
    duration: "2:54",
    image: "/images/music-cover-list-4.png",
    audioUrl: "/audio/wsugar.mp3",
  },
  {
    id: 5,
    title: "Levitating",
    artist: "Dua Lipa",
    album: "Future Nostalgia",
    duration: "3:23",
    image: "/images/music-cover-list-5.png",
    audioUrl: "/audio/levtating.mp3",
  },
  {
    id: 6,
    title: "Anti-Hero",
    artist: "Taylor Swift",
    album: "Midnights",
    duration: "3:20",
    image: "/images/music-cover-list-6.png",
    audioUrl: "/audio/antihero.mp3",
  },
  {
    id: 7,
    title: "As It Was",
    artist: "Harry Styles",
    album: "Harry's House",
    duration: "2:47",
    image: "/images/music-cover-list-7.png",
    audioUrl: "/audio/asitwas.mp3",
  },
  {
    id: 8,
    title: "Heat Waves",
    artist: "Glass Animals",
    album: "Dreamland",
    duration: "3:58",
    image: "/images/music-cover-list-8.png",
    audioUrl: "/audio/heatwaves.mp3",
  },
  {
    id: 9,
    title: "Stay",
    artist: "The Kid LAROI & Justin Bieber",
    album: "F*CK LOVE 3",
    duration: "2:21",
    image: "/images/music-cover-list-9.png",
    audioUrl: "/audio/stay.mp3",
  },
  {
    id: 10,
    title: "Good 4 U",
    artist: "Olivia Rodrigo",
    album: "SOUR",
    duration: "2:58",
    image: "/images/music-cover-list-10.png",
    audioUrl: "/audio/good4u.mp3",
  },
  {
    id: 11,
    title: "Industry Baby",
    artist: "Lil Nas X & Jack Harlow",
    album: "MONTERO",
    duration: "3:32",
    image: "/images/music-cover-list-11.png",
    audioUrl: "/audio/industrybaby.mp3",
  },
  {
    id: 12,
    title: "Peaches",
    artist: "Justin Bieber ft. Daniel Caesar",
    album: "Justice",
    duration: "3:18",
    image: "/images/music-cover-list-12.png",
    audioUrl: "/audio/peaches.mp3",
  },
  {
    id: 13,
    title: "Flowers",
    artist: "Miley Cyrus",
    album: "Endless Summer Vacation",
    duration: "3:20",
    image: "/images/music-cover-list-13.png",
    audioUrl: "/audio/flower.mp3",
  },
  {
    id: 14,
    title: "Unholy",
    artist: "Sam Smith ft. Kim Petras",
    album: "Gloria",
    duration: "2:36",
    image: "/images/music-cover-list-14.png",
    audioUrl: "/audio/unholy.mp3",
  },
  {
    id: 15,
    title: "About Damn Time",
    artist: "Lizzo",
    album: "Special",
    duration: "3:11",
    image: "/images/music-cover-list-15.png",
    audioUrl: "/audio/about-damn-time.mp3",
  },
  {
    id: 16,
    title: "Running Up That Hill",
    artist: "Kate Bush",
    album: "Hounds of Love",
    duration: "4:58",
    image: "/images/music-cover-list-16.png",
    audioUrl: "/audio/runningup.mp3",
  },
  {
    id: 17,
    title: "Sunflower",
    artist: "Post Malone & Swae Lee",
    album: "Spider-Verse Soundtrack",
    duration: "2:38",
    image: "/images/music-cover-list-17.png",
    audioUrl: "/audio/sunflower.mp3",
  },
  {
    id: 18,
    title: "Circles",
    artist: "Post Malone",
    album: "Hollywood's Bleeding",
    duration: "3:35",
    image: "/images/music-cover-list-18.png",
    audioUrl: "/audio/circles.mp3",
  },
  {
    id: 19,
    title: "Drivers License",
    artist: "Olivia Rodrigo",
    album: "SOUR",
    duration: "4:02",
    image: "/images/music-cover-list-19.png",
    audioUrl: "/audio/driverlicense.mp3",
  },
  {
    id: 20,
    title: "Starboy",
    artist: "The Weeknd ft. Daft Punk",
    album: "Starboy",
    duration: "3:50",
    image: "/images/music-cover-list-20.png",
    audioUrl: "/audio/starboy.mp3",
  },
];

const Library: React.FC = () => {
  const { playSong, togglePlay, currentSong, isPlaying } = useMusicPlayer();
  const [songDurations, setSongDurations] = useState<{ [key: number]: string }>(
    {}
  );

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const loadAudioDuration = useCallback((song: Song) => {
    if (song.audioUrl) {
      const audio = new Audio(song.audioUrl);
      audio.addEventListener("loadedmetadata", () => {
        setSongDurations((prev) => ({
          ...prev,
          [song.id]: formatTime(audio.duration),
        }));
      });
    }
  }, []);

  useEffect(() => {
    songs.forEach((song) => loadAudioDuration(song));
  }, [loadAudioDuration]);

  return (
    <div
      style={{
        padding: "2rem 3rem",
        minHeight: "100vh",
        backgroundColor: "var(--cream-primary)",
      }}
    >
      <h1
        style={{
          marginBottom: "2rem",
          color: "var(--text-primary)",
          fontSize: "2.5rem",
          fontWeight: "700",
        }}
      >
        Your Library
      </h1>
      <div>
        {songs.map((song) => (
          <div
            key={song.id}
            className="card"
            style={{
              display: "flex",
              alignItems: "center",
              padding: "1rem",
              marginBottom: "0.5rem",
              cursor: "pointer",
              transition: "transform 0.2s, box-shadow 0.2s",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = "translateY(-2px)";
              e.currentTarget.style.boxShadow = "var(--shadow-lg)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = "translateY(0)";
              e.currentTarget.style.boxShadow = "var(--shadow-md)";
            }}
          >
            <img
              src={song.image}
              alt={song.title}
              style={{
                width: "60px",
                height: "60px",
                borderRadius: "8px",
                objectFit: "cover",
                boxShadow: "var(--shadow-sm)",
              }}
            />
            <div style={{ flex: 1, marginLeft: "1rem" }}>
              <div
                style={{
                  fontWeight: "bold",
                  color: "var(--text-primary)",
                  fontSize: "1rem",
                  marginBottom: "0.25rem",
                }}
              >
                {song.title}
              </div>
              <div
                style={{
                  fontSize: "0.875rem",
                  color: "var(--text-secondary)",
                }}
              >
                {song.artist} • {song.album}
              </div>
            </div>
            <div
              style={{
                fontSize: "0.875rem",
                color: "var(--text-muted)",
                marginRight: "1rem",
              }}
            >
              {songDurations[song.id] || song.duration}
            </div>
            <button
              onClick={() => {
                if (currentSong?.id === song.id) {
                  togglePlay();
                } else {
                  playSong(song);
                }
              }}
              style={{
                background: "none",
                border: "none",
                cursor: "pointer",
                padding: "0.5rem",
                marginRight: "0.5rem",
                color: "var(--coffee-primary)",
                borderRadius: "50%",
                transition: "background-color 0.2s",
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.backgroundColor =
                  "var(--cream-secondary)")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.backgroundColor = "transparent")
              }
            >
              {currentSong?.id === song.id && isPlaying ? (
                <Pause size={20} />
              ) : (
                <Play size={20} />
              )}
            </button>
            <button
              style={{
                background: "none",
                border: "none",
                cursor: "pointer",
                padding: "0.5rem",
                color: "var(--coffee-light)",
                borderRadius: "50%",
                transition: "background-color 0.2s",
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.backgroundColor =
                  "var(--cream-secondary)")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.backgroundColor = "transparent")
              }
            >
              <MoreVertical size={20} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Library;
