import React from "react";
import { Heart, Play, MoreHorizontal } from "lucide-react";
import "../theme/theme.css";

interface LikedSong {
  id: number;
  title: string;
  artist: string;
  album: string;
  duration: string;
}

const LikedSongs: React.FC = () => {
  const likedSongs: LikedSong[] = [
    { id: 1, title: "Blinding Lights", artist: "The Weeknd", album: "After Hours", duration: "3:20" },
    { id: 2, title: "Watermelon Sugar", artist: "Harry Styles", album: "Fine Line", duration: "2:54" },
    { id: 3, title: "Levitating", artist: "Dua Lipa", album: "Future Nostalgia", duration: "3:23" },
    { id: 4, title: "Good 4 U", artist: "Olivia Rodrigo", album: "SOUR", duration: "2:58" },
    { id: 5, title: "Stay", artist: "The Kid LAROI, Justin Bieber", album: "F*CK LOVE 3", duration: "2:21" }
  ];

  return (
    <div style={{ minHeight: "100vh", background: "var(--gradient-warm)", padding: "2rem" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "2rem", marginBottom: "2rem" }}>
        <div style={{
          width: "200px",
          height: "200px",
          background: "linear-gradient(135deg, #ff6b6b, #ee5a24)",
          borderRadius: "8px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          boxShadow: "var(--shadow-lg)"
        }}>
          <Heart size={80} color="white" fill="white" />
        </div>
        <div>
          <p style={{ color: "var(--text-secondary)", margin: 0 }}>Playlist</p>
          <h1 style={{ fontSize: "4rem", fontWeight: "900", margin: "0.5rem 0", color: "var(--text-primary)" }}>
            Liked Songs
          </h1>
          <p style={{ color: "var(--text-secondary)", margin: 0 }}>{likedSongs.length} songs</p>
        </div>
      </div>

      <div style={{ marginBottom: "2rem" }}>
        <button style={{
          background: "var(--coffee-primary)",
          color: "white",
          border: "none",
          borderRadius: "50%",
          width: "60px",
          height: "60px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: "pointer",
          boxShadow: "var(--shadow-md)"
        }}>
          <Play size={24} fill="white" />
        </button>
      </div>

      <div>
        {likedSongs.map((song, index) => (
          <div key={song.id} style={{
            display: "grid",
            gridTemplateColumns: "50px 1fr 200px 100px 50px",
            alignItems: "center",
            padding: "0.75rem",
            borderRadius: "8px",
            cursor: "pointer",
            transition: "background-color 0.2s"
          }}
          onMouseEnter={(e) => (e.currentTarget as HTMLElement).style.backgroundColor = "var(--cream-secondary)"}
          onMouseLeave={(e) => (e.currentTarget as HTMLElement).style.backgroundColor = "transparent"}>
            <span style={{ color: "var(--text-secondary)" }}>{index + 1}</span>
            <div>
              <div style={{ fontWeight: "600", color: "var(--text-primary)" }}>{song.title}</div>
              <div style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>{song.artist}</div>
            </div>
            <div style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>{song.album}</div>
            <div style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>{song.duration}</div>
            <MoreHorizontal size={20} style={{ color: "var(--text-secondary)", cursor: "pointer" }} />
          </div>
        ))}
      </div>
    </div>
  );
};

export default LikedSongs;