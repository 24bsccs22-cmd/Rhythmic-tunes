import React, { useState, useRef, useEffect } from "react";
import { Shield, ArrowLeft } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import "../theme/theme.css";

const OTP: React.FC = () => {
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [error, setError] = useState("");
  const [isVerifying, setIsVerifying] = useState(false);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const navigate = useNavigate();
  const location = useLocation();
  const email = location.state?.email || "";

  useEffect(() => {
    inputRefs.current[0]?.focus();
  }, []);

  const handleChange = (index: number, value: string) => {
    if (value.length > 1) return;
    
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    setError("");

    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const otpValue = otp.join("");
    
    if (otpValue.length !== 6) {
      setError("Please enter complete OTP");
      return;
    }

    setIsVerifying(true);
    
    // Simulate OTP verification (in real app, verify with backend)
    setTimeout(() => {
      if (otpValue === "123456") {
        alert("Account verified successfully!");
        navigate("/login");
      } else {
        setError("Invalid OTP. Please try again.");
      }
      setIsVerifying(false);
    }, 1500);
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "var(--gradient-warm)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "2rem 1rem",
      }}
    >
      <div
        style={{
          background: "var(--card-background)",
          borderRadius: "16px",
          padding: "3rem",
          boxShadow: "var(--shadow-lg)",
          border: "1px solid var(--border-light)",
          width: "100%",
          maxWidth: "400px",
        }}
      >
        <button
          onClick={() => navigate("/register")}
          style={{
            background: "none",
            border: "none",
            color: "var(--text-secondary)",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: "0.5rem",
            marginBottom: "1rem",
            fontSize: "0.9rem",
          }}
        >
          <ArrowLeft size={16} />
          Back to Register
        </button>

        <div style={{ textAlign: "center", marginBottom: "2rem" }}>
          <div
            style={{
              background: "var(--gradient-coffee)",
              borderRadius: "50%",
              width: "80px",
              height: "80px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 auto 1rem auto",
            }}
          >
            <Shield size={40} color="white" />
          </div>
          <h1
            style={{
              fontSize: "2rem",
              fontWeight: "700",
              color: "var(--text-primary)",
              margin: "0 0 0.5rem 0",
            }}
          >
            Verify Your Account
          </h1>
          <p
            style={{
              color: "var(--text-secondary)",
              fontSize: "1rem",
              margin: 0,
            }}
          >
            Enter the 6-digit code sent to {email}
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          <div
            style={{
              display: "flex",
              gap: "0.5rem",
              justifyContent: "center",
              marginBottom: "2rem",
            }}
          >
            {otp.map((digit, index) => (
              <input
                key={index}
                ref={(el) => { inputRefs.current[index] = el; }}
                type="text"
                value={digit}
                onChange={(e) => handleChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                maxLength={1}
                style={{
                  width: "50px",
                  height: "50px",
                  textAlign: "center",
                  fontSize: "1.5rem",
                  fontWeight: "600",
                  border: "2px solid var(--input-border)",
                  borderRadius: "8px",
                  background: "var(--input-background)",
                  color: "var(--text-primary)",
                  outline: "none",
                }}
              />
            ))}
          </div>

          {error && (
            <div
              style={{
                marginBottom: "1rem",
                padding: "0.75rem",
                background: "#fee2e2",
                border: "1px solid #fecaca",
                borderRadius: "8px",
                color: "#dc2626",
                fontSize: "0.9rem",
                textAlign: "center",
              }}
            >
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={isVerifying}
            style={{
              width: "100%",
              padding: "0.875rem",
              background: isVerifying ? "var(--text-secondary)" : "var(--gradient-hero)",
              color: "white",
              border: "none",
              borderRadius: "8px",
              fontSize: "1rem",
              fontWeight: "600",
              cursor: isVerifying ? "not-allowed" : "pointer",
            }}
          >
            {isVerifying ? "Verifying..." : "Verify Account"}
          </button>
        </form>

        <div
          style={{
            marginTop: "2rem",
            padding: "1rem",
            background: "var(--cream-secondary)",
            borderRadius: "8px",
            textAlign: "center",
          }}
        >
          <p
            style={{
              fontSize: "0.85rem",
              color: "var(--text-secondary)",
              margin: 0,
            }}
          >
            Demo: Use OTP <strong>123456</strong> to verify
          </p>
        </div>
      </div>
    </div>
  );
};

export default OTP;