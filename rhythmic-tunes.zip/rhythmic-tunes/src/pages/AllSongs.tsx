import React, { useState } from "react";
import { Heart, Play, Pause, MoreHorizontal } from "lucide-react";
import { useLikedSongs } from "../context/LikedSongsContext.tsx";
import "../theme/theme.css";

interface Song {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: string;
  image: string;
}

const AllSongs: React.FC = () => {
  const { addToLiked, removeFromLiked, isLiked } = useLikedSongs();
  const [currentView, setCurrentView] = useState<'all' | 'liked'>('all');
  const [currentlyPlaying, setCurrentlyPlaying] = useState<string | null>(null);

  const allSongs: Song[] = [
    {
      id: '1',
      title: 'Blinding Lights',
      artist: 'The Weeknd',
      album: 'After Hours',
      duration: '3:22',
      image: 'https://picsum.photos/seed/song1/80/80'
    },
    {
      id: '2',
      title: 'Watermelon Sugar',
      artist: 'Harry Styles',
      album: 'Fine Line',
      duration: '2:54',
      image: 'https://picsum.photos/seed/song2/80/80'
    },
    {
      id: '3',
      title: 'Good 4 U',
      artist: 'Olivia Rodrigo',
      album: 'SOUR',
      duration: '2:58',
      image: 'https://picsum.photos/seed/song3/80/80'
    },
    {
      id: '4',
      title: 'Levitating',
      artist: 'Dua Lipa',
      album: 'Future Nostalgia',
      duration: '3:23',
      image: 'https://picsum.photos/seed/song4/80/80'
    },
    {
      id: '5',
      title: 'drivers license',
      artist: 'Olivia Rodrigo',
      album: 'SOUR',
      duration: '4:02',
      image: 'https://picsum.photos/seed/song5/80/80'
    }
  ];

  const handleLike = (song: Song) => {
    if (isLiked(song.id)) {
      removeFromLiked(song.id);
    } else {
      addToLiked(song);
    }
  };

  const togglePlay = (songId: string) => {
    setCurrentlyPlaying(current => current === songId ? null : songId);
  };

  const likedSongs = allSongs.filter(song => isLiked(song.id));

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "var(--gradient-warm)",
      }}
    >
      <div style={{ padding: "2rem 3rem" }}>
        <div style={{ marginBottom: "2rem" }}>
          <h1
            style={{
              fontSize: "2.5rem",
              fontWeight: "900",
              marginBottom: "1rem",
              color: "var(--text-primary)",
            }}
          >
            Music Library
          </h1>
          
          <div style={{ display: "flex", gap: "1rem" }}>
            <button
              onClick={() => setCurrentView('all')}
              style={{
                padding: "0.75rem 1.5rem",
                borderRadius: "8px",
                border: "none",
                fontWeight: "600",
                cursor: "pointer",
                transition: "all 0.2s",
                backgroundColor: currentView === 'all' ? "var(--coffee-primary)" : "rgba(255,255,255,0.1)",
                color: "white",
              }}
            >
              All Songs
            </button>
            <button
              onClick={() => setCurrentView('liked')}
              style={{
                padding: "0.75rem 1.5rem",
                borderRadius: "8px",
                border: "none",
                fontWeight: "600",
                cursor: "pointer",
                transition: "all 0.2s",
                backgroundColor: currentView === 'liked' ? "#ff6b6b" : "rgba(255,255,255,0.1)",
                color: "white",
                display: "flex",
                alignItems: "center",
                gap: "0.5rem",
              }}
            >
              <Heart size={16} fill={currentView === 'liked' ? "white" : "transparent"} />
              Liked Songs ({likedSongs.length})
            </button>
          </div>
        </div>

        <div style={{ backgroundColor: "rgba(255,255,255,0.05)", borderRadius: "12px", padding: "1.5rem" }}>
          {currentView === 'all' ? (
            <div>
              <h2 style={{ fontSize: "1.5rem", fontWeight: "700", marginBottom: "1.5rem", color: "var(--text-primary)" }}>
                All Songs
              </h2>
              <div style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
                {allSongs.map(song => (
                  <div
                    key={song.id}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      padding: "0.75rem",
                      borderRadius: "8px",
                      cursor: "pointer",
                      transition: "background-color 0.2s",
                      backgroundColor: "transparent",
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = "rgba(255,255,255,0.1)";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = "transparent";
                    }}
                  >
                    <div style={{ position: "relative", marginRight: "1rem" }}>
                      <img
                        src={song.image}
                        alt={song.title}
                        style={{
                          width: "48px",
                          height: "48px",
                          borderRadius: "6px",
                          objectFit: "cover",
                        }}
                      />
                      <div
                        style={{
                          position: "absolute",
                          inset: "0",
                          backgroundColor: "rgba(0,0,0,0.4)",
                          borderRadius: "6px",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          opacity: "0",
                          transition: "opacity 0.2s",
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.opacity = "1";
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.opacity = "0";
                        }}
                      >
                        <button
                          onClick={() => togglePlay(song.id)}
                          style={{
                            width: "24px",
                            height: "24px",
                            backgroundColor: "white",
                            borderRadius: "50%",
                            border: "none",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            cursor: "pointer",
                          }}
                        >
                          {currentlyPlaying === song.id ? (
                            <Pause size={12} color="black" />
                          ) : (
                            <Play size={12} color="black" style={{ marginLeft: "1px" }} />
                          )}
                        </button>
                      </div>
                    </div>
                    
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <h3 style={{ fontSize: "1rem", fontWeight: "500", margin: 0, color: "var(--text-primary)" }}>
                        {song.title}
                      </h3>
                      <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", margin: "2px 0 0 0" }}>
                        {song.artist}
                      </p>
                    </div>
                    
                    <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
                      <span style={{ fontSize: "0.85rem", color: "var(--text-secondary)" }}>
                        {song.duration}
                      </span>
                      <button
                        onClick={() => handleLike(song)}
                        style={{
                          background: "none",
                          border: "none",
                          cursor: "pointer",
                          padding: "8px",
                          borderRadius: "50%",
                          transition: "background-color 0.2s",
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.backgroundColor = "rgba(255,255,255,0.1)";
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.backgroundColor = "transparent";
                        }}
                      >
                        <Heart
                          size={16}
                          fill={isLiked(song.id) ? "#ff6b6b" : "transparent"}
                          color={isLiked(song.id) ? "#ff6b6b" : "var(--text-secondary)"}
                        />
                      </button>
                      <button
                        style={{
                          background: "none",
                          border: "none",
                          cursor: "pointer",
                          padding: "8px",
                          borderRadius: "50%",
                          transition: "background-color 0.2s",
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.backgroundColor = "rgba(255,255,255,0.1)";
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.backgroundColor = "transparent";
                        }}
                      >
                        <MoreHorizontal size={16} color="var(--text-secondary)" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div>
              <h2 style={{ fontSize: "1.5rem", fontWeight: "700", marginBottom: "1.5rem", color: "var(--text-primary)" }}>
                Liked Songs ({likedSongs.length})
              </h2>
              {likedSongs.length > 0 ? (
                <div style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
                  {likedSongs.map(song => (
                    <div
                      key={song.id}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        padding: "0.75rem",
                        borderRadius: "8px",
                        cursor: "pointer",
                        transition: "background-color 0.2s",
                        backgroundColor: "transparent",
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = "rgba(255,255,255,0.1)";
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = "transparent";
                      }}
                    >
                      <img
                        src={song.image}
                        alt={song.title}
                        style={{
                          width: "48px",
                          height: "48px",
                          borderRadius: "6px",
                          objectFit: "cover",
                          marginRight: "1rem",
                        }}
                      />
                      <div style={{ flex: 1 }}>
                        <h3 style={{ fontSize: "1rem", fontWeight: "500", margin: 0, color: "var(--text-primary)" }}>
                          {song.title}
                        </h3>
                        <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", margin: "2px 0 0 0" }}>
                          {song.artist}
                        </p>
                      </div>
                      <span style={{ fontSize: "0.85rem", color: "var(--text-secondary)", marginRight: "1rem" }}>
                        {song.duration}
                      </span>
                      <button
                        onClick={() => handleLike(song)}
                        style={{
                          background: "none",
                          border: "none",
                          cursor: "pointer",
                          padding: "8px",
                          borderRadius: "50%",
                          transition: "background-color 0.2s",
                        }}
                      >
                        <Heart size={16} fill="#ff6b6b" color="#ff6b6b" />
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <div style={{ textAlign: "center", padding: "4rem 0" }}>
                  <Heart size={64} color="var(--text-secondary)" style={{ marginBottom: "1rem" }} />
                  <h3 style={{ fontSize: "1.25rem", fontWeight: "600", color: "var(--text-secondary)", marginBottom: "0.5rem" }}>
                    No liked songs yet
                  </h3>
                  <p style={{ color: "var(--text-secondary)", marginBottom: "1.5rem" }}>
                    Start liking songs to see them here!
                  </p>
                  <button
                    onClick={() => setCurrentView('all')}
                    style={{
                      padding: "0.75rem 1.5rem",
                      backgroundColor: "var(--coffee-primary)",
                      color: "white",
                      border: "none",
                      borderRadius: "8px",
                      fontWeight: "600",
                      cursor: "pointer",
                      transition: "transform 0.2s",
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = "scale(1.05)";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = "scale(1)";
                    }}
                  >
                    Browse Songs
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AllSongs;