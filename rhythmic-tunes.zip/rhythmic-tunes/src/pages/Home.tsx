import React from "react";
import { Play, Heart } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useLikedSongs } from "../context/LikedSongsContext.tsx";
import "../theme/theme.css";

const Home: React.FC = () => {
  const navigate = useNavigate();
  const { addToLiked, removeFromLiked, isLiked } = useLikedSongs();

  const handleLike = (e: React.MouseEvent, song: {id: string, title: string, artist: string, image: string}) => {
    e.stopPropagation();
    if (isLiked(song.id)) {
      removeFromLiked(song.id);
    } else {
      addToLiked(song);
    }
  };
  
  const getRouteForSection = (title: string) => {
    const routes: { [key: string]: string } = {
      "Liked Songs": "/liked-songs",
      "Recently Played": "/recently-played", 
      "Daily Mix 1": "/daily-mix",
      "Discover Weekly": "/discover-weekly",
      "Your favorite artist": "/top-artist",
      "Your Top Songs 2024": "/top-songs",
      "All Songs": "/all-songs"
    };
    return routes[title] || "/";
  };

  const playlists = [
    {
      id: 1,
      title: "Today's Top Hits",
      description: "The most played songs right now",
      image: "https://picsum.photos/seed/album1/200/200",
    },
    {
      id: 2,
      title: "RapCaviar",
      description: "New music from Drake, Travis Scott and more",
      image: "https://picsum.photos/seed/album2/200/200",
    },
    {
      id: 3,
      title: "All Out 2010s",
      description: "The biggest songs of the 2010s",
      image: "https://picsum.photos/seed/album3/200/200",
    },
    {
      id: 4,
      title: "Rock Classics",
      description: "Rock legends & epic songs",
      image: "https://picsum.photos/seed/album4/200/200",
    },
    {
      id: 5,
      title: "Chill Hits",
      description: "Kick back to the best new and recent chill hits",
      image: "https://picsum.photos/seed/album5/200/200",
    },
    {
      id: 6,
      title: "Viva Latino",
      description: "Today's top Latin hits",
      image: "https://picsum.photos/seed/album6/200/200",
    },
    {
      id: 7,
      title: "Peaceful Piano",
      description: "Relax and indulge with beautiful piano pieces",
      image: "https://picsum.photos/seed/album7/200/200",
    },
    {
      id: 8,
      title: "Deep Focus",
      description: "Keep calm and focus with ambient music",
      image: "https://picsum.photos/seed/album8/200/200",
    },
    {
      id: 9,
      title: "Jazz Vibes",
      description: "The original chill playlist",
      image: "https://picsum.photos/seed/album9/200/200",
    },
    {
      id: 10,
      title: "Pop Rising",
      description: "Rising stars and breakthrough songs",
      image: "https://picsum.photos/seed/album10/200/200",
    },
  ];

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "var(--gradient-warm)",
      }}
    >
      <div style={{ padding: "2rem 3rem" }}>
        <div style={{ marginBottom: "3rem" }}>
          <h1
            style={{
              fontSize: "3rem",
              fontWeight: "900",
              marginBottom: "0.5rem",
              letterSpacing: "-0.02em",
              color: "var(--text-primary)",
            }}
          >
            Hello
          </h1>
          <p
            style={{
              fontSize: "1.1rem",
              margin: 0,
              fontWeight: "400",
              color: "var(--text-secondary)",
            }}
          >
            Let's find something amazing to listen to
          </p>
        </div>

        <section style={{ marginBottom: "3rem" }}>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
              gap: "1rem",
              marginBottom: "3rem",
            }}
          >
            {[
              {
                title: "Liked Songs",
                image: "https://picsum.photos/seed/liked2/80/80",
                color: "var(--coffee-primary)",
              },
              {
                title: "Recently Played",
                image: "https://picsum.photos/seed/recent/80/80",
                color: "var(--orange-primary)",
              },
              {
                title: "Daily Mix 1",
                image: "https://picsum.photos/seed/daily2/80/80",
                color: "var(--coffee-secondary)",
              },
              {
                title: "Discover Weekly",
                image: "https://picsum.photos/seed/discover/80/80",
                color: "var(--coffee-light)",
              },
              {
                title: "Your favorite artist",
                image: "https://picsum.photos/seed/release/80/80",
                color: "var(--orange-muted)",
              },
              {
                title: "Your Top Songs 2024",
                image: "https://picsum.photos/seed/top2024/80/80",
                color: "var(--coffee-dark)",
              },
              {
                title: "All Songs",
                image: "https://picsum.photos/seed/allsongs/80/80",
                color: "var(--orange-secondary)",
              },
            ].map((item, index) => (
              <div
                key={index}
                onClick={() => navigate(getRouteForSection(item.title))}
                style={{
                  display: "flex",
                  alignItems: "center",
                  backgroundColor: item.color,
                  borderRadius: "8px",
                  overflow: "hidden",
                  cursor: "pointer",
                  transition: "all 0.2s",
                  boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
                  height: "80px",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "scale(1.02)";
                  e.currentTarget.style.boxShadow =
                    "0 6px 20px rgba(0,0,0,0.25)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "scale(1)";
                  e.currentTarget.style.boxShadow =
                    "0 4px 12px rgba(0,0,0,0.15)";
                }}
              >
                <img
                  src={item.image}
                  alt={item.title}
                  style={{
                    width: "80px",
                    height: "80px",
                    objectFit: "cover",
                  }}
                />
                <h3
                  style={{
                    color: "white",
                    fontSize: "1rem",
                    fontWeight: "700",
                    margin: "0 0 0 1rem",
                    textShadow: "0 1px 3px rgba(0,0,0,0.3)",
                  }}
                >
                  {item.title}
                </h3>
              </div>
            ))}
          </div>
        </section>

        <section style={{ marginBottom: "3rem" }}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: "1.5rem",
            }}
          >
            <h2
              style={{
                fontSize: "1.5rem",
                fontWeight: "700",
                margin: 0,
                color: "var(--text-primary)",
              }}
            >
              Made for you
            </h2>
            <button
              style={{
                background: "none",
                border: "none",
                fontSize: "0.9rem",
                fontWeight: "600",
                cursor: "pointer",
                textDecoration: "underline",
                color: "var(--text-secondary)",
              }}
            >
              Show all
            </button>
          </div>

          <div
            style={{
              padding:"10px",
              display: "flex",
              gap: "1.5rem",
              overflowX: "auto",
              paddingBottom: "1rem",
            }}
            className="hide-scrollbar"
          >
            {playlists.map((playlist) => (
              <div
                key={playlist.id}
                onClick={() => navigate(`/playlist/${playlist.id}`)}
                style={{
                  minWidth: "200px",
                  cursor: "pointer",
                  transition: "transform 0.2s",
                }}
                onMouseEnter={(e) =>
                  (e.currentTarget.style.transform = "scale(1.02)")
                }
                onMouseLeave={(e) =>
                  (e.currentTarget.style.transform = "scale(1)")
                }
              >
                <div
                  style={{
                    position: "relative",
                    width: "200px",
                    height: "200px",
                    borderRadius: "8px",
                    overflow: "hidden",
                    boxShadow: "0 8px 24px rgba(0,0,0,0.15)",
                    marginBottom: "0.75rem",
                  }}
                >
                  <img
                    src={playlist.image}
                    alt={playlist.title}
                    style={{
                      width: "100%",
                      height: "100%",
                      objectFit: "cover",
                    }}
                  />
                  <button
                    className="btn-primary"
                    style={{
                      position: "absolute",
                      bottom: "12px",
                      right: "12px",
                      width: "40px",
                      height: "40px",
                      borderRadius: "50%",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      cursor: "pointer",
                      transition: "transform 0.2s",
                    }}
                    onMouseEnter={(e) =>
                      (e.currentTarget.style.transform = "scale(1.1)")
                    }
                    onMouseLeave={(e) =>
                      (e.currentTarget.style.transform = "scale(1)")
                    }
                  >
                    <Play size={16} fill="white" />
                  </button>

                </div>
                <h3
                  style={{
                    fontSize: "1rem",
                    fontWeight: "700",
                    margin: "0 0 0.25rem 0",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                    color: "var(--text-primary)",
                  }}
                >
                  {playlist.title}
                </h3>
                <p
                  style={{
                    fontSize: "0.85rem",
                    margin: 0,
                    color: "var(--text-secondary)",
                    lineHeight: "1.4",
                    overflow: "hidden",
                    display: "-webkit-box",
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: "vertical",
                  }}
                >
                  {playlist.description}
                </p>
              </div>
            ))}
          </div>
        </section>

        <section style={{ marginBottom: "3rem" }}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: "1.5rem",
            }}
          >
            <h2
              className="text-primary"
              style={{
                fontSize: "1.5rem",
                fontWeight: "700",
                margin: 0,
              }}
            >
              Recently played
            </h2>
            <button
              className="text-medium"
              style={{
                background: "none",
                border: "none",
                fontSize: "0.9rem",
                fontWeight: "600",
                cursor: "pointer",
                textDecoration: "underline",
              }}
            >
              Show all
            </button>
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(350px, 1fr))",
              gap: "0.5rem",
            }}
          >
            {[
              {
                id: "song1",
                title: "Blinding Lights",
                artist: "The Weeknd",
                image: "https://picsum.photos/seed/song1/80/80",
              },
            ].map((song, index) => (
              <div
                key={index}
                style={{
                  display: "flex",
                  alignItems: "center",
                  padding: "0.5rem",
                  borderRadius: "6px",
                  cursor: "pointer",
                  transition: "background-color 0.2s",
                  backgroundColor: "transparent",
                  position: "relative",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor =
                    "rgba(255,255,255,0.1)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = "transparent";
                }}
              >
                <img
                  src={song.image}
                  alt={song.title}
                  style={{
                    width: "60px",
                    height: "60px",
                    borderRadius: "4px",
                    objectFit: "cover",
                    marginRight: "1rem",
                  }}
                />
                <div style={{ flex: 1 }}>
                  <h3
                    className="text-dark"
                    style={{
                      fontSize: "1rem",
                      fontWeight: "500",
                      margin: 0,
                    }}
                  >
                    {song.title}
                  </h3>
                  <p
                    style={{
                      fontSize: "0.85rem",
                      color: "var(--text-secondary)",
                      margin: "2px 0 0 0",
                    }}
                  >
                    {song.artist}
                  </p>
                </div>
                <button
                  onClick={(e) => handleLike(e, song)}
                  style={{
                    background: "none",
                    border: "none",
                    cursor: "pointer",
                    padding: "8px",
                    borderRadius: "50%",
                    transition: "background-color 0.2s",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = "rgba(255,255,255,0.1)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = "transparent";
                  }}
                >
                  <Heart
                    size={16}
                    fill={isLiked(song.id) ? "#ff6b6b" : "transparent"}
                    color={isLiked(song.id) ? "#ff6b6b" : "var(--text-secondary)"}
                  />
                </button>
              </div>
            ))}
          </div>
        </section>

        <section>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: "1.5rem",
            }}
          >
            <h2
              className="text-primary"
              style={{
                fontSize: "1.5rem",
                fontWeight: "700",
                margin: 0,
              }}
            >
              Your top artists
            </h2>
            <button
              className="text-medium"
              style={{
                background: "none",
                border: "none",
                fontSize: "0.9rem",
                fontWeight: "600",
                cursor: "pointer",
                textDecoration: "underline",
              }}
            >
              Show all
            </button>
          </div>

          <div
            style={{
              display: "flex",
              gap: "2rem",
              overflowX: "auto",
              paddingBottom: "1rem",
            }}
            className="hide-scrollbar"
          >
            {[
              { name: "Taylor Swift", image: "/images/Taylor Swift.png" },
              { name: "Ed Sheeran", image: "/images/Ed Sheeran.png" },
              { name: "Billie Eilish", image: "/images/Billie Eilish.png" },
              { name: "Drake", image: "/images/Drake.png" },
              { name: "Ariana Grande", image: "/images/Ariana Grande.png" },
              { name: "The Weeknd", image: "/images/The Weeknd.png" },
              { name: "Dua Lipa", image: "/images/Dua Lipa.png" },
              { name: "Post Malone", image: "/images/Post Malone.png" },
              { name: "Olivia Rodrigo", image: "/images/Olivia Rodrigo.png" },
              { name: "Harry Styles", image: "/images/Harry Styles.png" },
            ].map((artist, index) => (
              <div
                key={index}
                style={{
                  margin: "1rem",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  minWidth: "160px",
                  cursor: "pointer",
                  transition: "transform 0.2s",
                }}
                onMouseEnter={(e) =>
                  (e.currentTarget.style.transform = "scale(1.05)")
                }
                onMouseLeave={(e) =>
                  (e.currentTarget.style.transform = "scale(1)")
                }
              >
                <div
                  style={{
                    width: "160px",
                    height: "160px",
                    borderRadius: "50%",
                    overflow: "hidden",
                    marginBottom: "0.75rem",
                    boxShadow: "0 8px 24px rgba(0,0,0,0.15)",
                  }}
                >
                  <img
                    src={artist.image}
                    alt={artist.name}
                    style={{
                      width: "100%",
                      height: "100%",
                      objectFit: "cover",
                    }}
                  />
                </div>
                <h4
                  className="text-dark"
                  style={{
                    fontSize: "1rem",
                    fontWeight: "600",
                    margin: 0,
                    textAlign: "center",
                    maxWidth: "160px",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  }}
                >
                  {artist.name}
                </h4>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default Home;
