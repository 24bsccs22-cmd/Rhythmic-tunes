import React from "react";
import { Clock, Play } from "lucide-react";
import "../theme/theme.css";

interface RecentSong {
  id: number;
  title: string;
  artist: string;
  image: string;
  time: string;
}

const RecentlyPlayed: React.FC = () => {
  const recentSongs: RecentSong[] = [
    { id: 1, title: "As It Was", artist: "Harry Styles", image: "https://picsum.photos/seed/recent1/60/60", time: "2 hours ago" },
    { id: 2, title: "Heat Waves", artist: "Glass Animals", image: "https://picsum.photos/seed/recent2/60/60", time: "5 hours ago" },
    { id: 3, title: "Anti-Hero", artist: "Taylor Swift", image: "https://picsum.photos/seed/recent3/60/60", time: "1 day ago" },
    { id: 4, title: "Unholy", artist: "Sam Smith ft. Kim Petras", image: "https://picsum.photos/seed/recent4/60/60", time: "2 days ago" },
    { id: 5, title: "Flowers", artist: "Miley Cyrus", image: "https://picsum.photos/seed/recent5/60/60", time: "3 days ago" }
  ];

  return (
    <div style={{ minHeight: "100vh", background: "var(--gradient-warm)", padding: "2rem" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "2rem", marginBottom: "2rem" }}>
        <div style={{
          width: "200px",
          height: "200px",
          background: "var(--gradient-coffee)",
          borderRadius: "8px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          boxShadow: "var(--shadow-lg)"
        }}>
          <Clock size={80} color="white" />
        </div>
        <div>
          <p style={{ color: "var(--text-secondary)", margin: 0 }}>Your Library</p>
          <h1 style={{ fontSize: "4rem", fontWeight: "900", margin: "0.5rem 0", color: "var(--text-primary)" }}>
            Recently Played
          </h1>
          <p style={{ color: "var(--text-secondary)", margin: 0 }}>Your listening history</p>
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
        {recentSongs.map((song) => (
          <div key={song.id} style={{
            display: "flex",
            alignItems: "center",
            gap: "1rem",
            padding: "1rem",
            background: "var(--card-background)",
            borderRadius: "12px",
            cursor: "pointer",
            transition: "transform 0.2s",
            boxShadow: "var(--shadow-sm)"
          }}
          onMouseEnter={(e) => (e.currentTarget as HTMLElement).style.transform = "scale(1.02)"}
          onMouseLeave={(e) => (e.currentTarget as HTMLElement).style.transform = "scale(1)"}>
            <img src={song.image} alt={song.title} style={{ width: "60px", height: "60px", borderRadius: "8px" }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: "600", color: "var(--text-primary)" }}>{song.title}</div>
              <div style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>{song.artist}</div>
            </div>
            <div style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>{song.time}</div>
            <button style={{
              background: "var(--coffee-primary)",
              color: "white",
              border: "none",
              borderRadius: "50%",
              width: "40px",
              height: "40px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer"
            }}>
              <Play size={16} fill="white" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RecentlyPlayed;