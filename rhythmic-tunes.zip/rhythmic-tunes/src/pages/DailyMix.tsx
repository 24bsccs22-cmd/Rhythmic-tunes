import React from "react";
import { Shuffle, Play } from "lucide-react";
import "../theme/theme.css";

interface Song {
  id: number;
  title: string;
  artist: string;
  image: string;
}

const DailyMix: React.FC = () => {
  const mixSongs: Song[] = [
    { id: 1, title: "Shape of You", artist: "Ed Sheeran", image: "https://picsum.photos/seed/mix1/60/60" },
    { id: 2, title: "Perfect", artist: "Ed Sheeran", image: "https://picsum.photos/seed/mix2/60/60" },
    { id: 3, title: "Thinking Out Loud", artist: "Ed Sheeran", image: "https://picsum.photos/seed/mix3/60/60" },
    { id: 4, title: "Photograph", artist: "Ed Sheeran", image: "https://picsum.photos/seed/mix4/60/60" },
    { id: 5, title: "Castle on the Hill", artist: "Ed Sheeran", image: "https://picsum.photos/seed/mix5/60/60" }
  ];

  return (
    <div style={{ minHeight: "100vh", background: "var(--gradient-warm)", padding: "2rem" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "2rem", marginBottom: "2rem" }}>
        <div style={{
          width: "200px",
          height: "200px",
          background: "var(--coffee-secondary)",
          borderRadius: "8px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          boxShadow: "var(--shadow-lg)"
        }}>
          <Shuffle size={80} color="white" />
        </div>
        <div>
          <p style={{ color: "var(--text-secondary)", margin: 0 }}>Made for you</p>
          <h1 style={{ fontSize: "4rem", fontWeight: "900", margin: "0.5rem 0", color: "var(--text-primary)" }}>
            Daily Mix 1
          </h1>
          <p style={{ color: "var(--text-secondary)", margin: 0 }}>Ed Sheeran, Taylor Swift, and more</p>
        </div>
      </div>

      <div style={{ display: "flex", gap: "1rem", marginBottom: "2rem" }}>
        <button style={{
          background: "var(--coffee-primary)",
          color: "white",
          border: "none",
          borderRadius: "50%",
          width: "60px",
          height: "60px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: "pointer",
          boxShadow: "var(--shadow-md)"
        }}>
          <Play size={24} fill="white" />
        </button>
        <button style={{
          background: "transparent",
          color: "var(--text-secondary)",
          border: "1px solid var(--border-medium)",
          borderRadius: "50%",
          width: "60px",
          height: "60px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: "pointer"
        }}>
          <Shuffle size={24} />
        </button>
      </div>

      <div style={{ display: "grid", gap: "0.5rem" }}>
        {mixSongs.map((song, index) => (
          <div key={song.id} style={{
            display: "flex",
            alignItems: "center",
            gap: "1rem",
            padding: "0.75rem",
            borderRadius: "8px",
            cursor: "pointer",
            transition: "background-color 0.2s"
          }}
          onMouseEnter={(e) => (e.currentTarget as HTMLElement).style.backgroundColor = "var(--cream-secondary)"}
          onMouseLeave={(e) => (e.currentTarget as HTMLElement).style.backgroundColor = "transparent"}>
            <span style={{ color: "var(--text-secondary)", width: "20px" }}>{index + 1}</span>
            <img src={song.image} alt={song.title} style={{ width: "50px", height: "50px", borderRadius: "4px" }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: "600", color: "var(--text-primary)" }}>{song.title}</div>
              <div style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>{song.artist}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DailyMix;